# Copyright (C) 2012 IBM Corporation and Others. All Rights Reserved.

This test may be tested on a linux machine like so:

 $ env XTRA_OPTS='-fPIC' icurun -i /path/to/icu-build testmap.c

Where /path/to/icu-build is the path to an ICU build dir

And where icurun is from : http://source.icu-project.org/repos/icu/tools/trunk/scripts/icurun

