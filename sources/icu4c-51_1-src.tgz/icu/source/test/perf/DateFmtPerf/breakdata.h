/*
**********************************************************************
* Copyright (c) 2002-2010,International Business Machines
* Corporation and others.  All Rights Reserved.
**********************************************************************
**********************************************************************
*/

#include "unicode/unistr.h"


UnicodeString str = 
"Please note neither this listing nor its contents are final til midnight of the last day of the month of any such announcement."
"The official release date of all Project Gutenberg Etexts is at"
"Midnight, Central Time, of the last day of the stated month.  A"
"preliminary version may often be posted for suggestion, comment"
"and editing by those who wish to do so.";
